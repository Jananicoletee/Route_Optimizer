import googlemaps
import pandas as pd
from itertools import permutations

def calculate_distance(client, origins, destinations):
    distance_matrix = client.distance_matrix(
        origins=origins,
        destinations=destinations,
        mode="driving",
    )

    distances = []
    for row in distance_matrix["rows"]:
        row_distances = [element["distance"]["value"] for element in row["elements"]]
        distances.append(row_distances)

    return distances

def generate_routes(client, orders):
    all_routes = []
    order_locations = [order["location"] for order in orders]
    distance_matrix = calculate_distance(client, order_locations, order_locations)

    for route in permutations(range(len(orders))):
        total_distance = 0
        for i in range(len(route) - 1):
            total_distance += distance_matrix[route[i]][route[i + 1]]

        all_routes.append((route, total_distance))

    return all_routes

def find_optimal_route(client, orders):
    all_routes = generate_routes(client, orders)
    optimal_route = min(all_routes, key=lambda x: x[1])
    return optimal_route

if __name__ == "__main__":
    # Replace 'YOUR_API_KEY' with your actual Google Maps API key.
    api_key = 'AIzaSyB4yw-Ru9QMxb3M9XN95jVLrm-padNbWRE'
    gmaps = googlemaps.Client(key=api_key)

    # Read data from Excel file
    excel_file_path = 'shutup.xlsx'
    df = pd.read_excel(excel_file_path)

    # Assuming the Excel file has a column named 'Location' with values like 'latitude,longitude'
    df[['Latitude', 'Longitude']] = df['CF.Lat & Long'].str.split(',', expand=True)

    # Convert the Latitude and Longitude columns to numeric
    df['Latitude'] = pd.to_numeric(df['Latitude'])
    df['Longitude'] = pd.to_numeric(df['Longitude'])

    # Example assuming the Excel file has 'Latitude' and 'Longitude' columns
    orders = [
        {"id": i+1, "location": (row["Latitude"], row["Longitude"])}
        for i, row in df.iterrows()
    ]

    optimal_route = find_optimal_route(gmaps, orders)
    print("Optimal Route:", [orders[i] for i in optimal_route[0]])
    print("Total Distance (in meters):", optimal_route[1])
